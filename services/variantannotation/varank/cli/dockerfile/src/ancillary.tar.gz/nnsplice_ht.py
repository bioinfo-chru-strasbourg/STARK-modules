#!/usr/bin/python
# -*- coding: latin1 -*-
#

# nnsplice_ht.py <min_donor> <min_acc> <seq_file>
# min_donor and min_acc are passed through arguments
# sequences are stored in a tmp file which filename is passed as an argument

import os
import re
import sys
import time
import signal
import subprocess

from tempfile import NamedTemporaryFile

# Le serveur NNSPLICE n'accepte pas de sequences > 100Kb au total.
# Si on a + grand, il faut decouper nos seq, l'appeler x fois et
# rabouter les resultats.
MAX_SEQ_LEN_FOR_NNSPLICE = 100000
SEQ_SECTION_LEN = 40000     # 2 x SEQ_SECTION_LEN < MAX_SEQ_LEN_FOR_NNSPLICE
SEQ_SECTION_OVERLAP = 50

nnspliceDir = 'NNSPLICE0.9/bin'
tmpdir = "tmp/"

#-------------------------------------------------------------------------------
def main():

    try:
        if (len(sys.argv) != 4):
            print "usage: nnsplice_ht.py <min_donor> <min_acc> <seq_file>"
            sys.exit(-1)
        min_donor = sys.argv[-3]
        min_acc = sys.argv[-2]
        seq_file = sys.argv[-1]

        fi = open(seq_file)
        sequences = fi.read()
        fi.close()

        seqLines = sequences.split('\n')
        seqRef = seqLines[1]
        seqMut = seqLines[3]
        seqRefLen = len(seqRef)
        seqMutLen = len(seqMut)

        i = 0
        seqSections = []    # [(sectionRef0, sectionMut0, offset0)...(sectionRefN, sectionMutN, offsetN)]
        while i < seqRefLen or i < seqMutLen:
            sectionRef = seqRef[i:i+SEQ_SECTION_LEN]
            sectionMut = seqMut[i:i+SEQ_SECTION_LEN]
            seqSections.append((sectionRef, sectionMut, i))
            i = i + SEQ_SECTION_LEN - SEQ_SECTION_OVERLAP

        # FW: change to local nnsplice
        nnsplice = NNSplice(min_donor, min_acc)
        for i in range(len(seqSections)):
            nnsplice.predict('Ref', seqSections[i][0], seqSections[i][2])
            nnsplice.predict('Mut', seqSections[i][1], seqSections[i][2])
            if i < len(seqSections) - 1:
                time.sleep(1)

        print 'NNSPLICE'

        for slotName in nnsplice.results.keys():
            print slotName
            for res in nnsplice.results[slotName]:
                print '\t%i\t%i\t%s' % res

        return

    except:
        import traceback
        errtime = '--- '+ time.ctime(time.time()) +' ---\n'
        errlog = open('nnsplice_error.log', 'a')
        errlog.write(errtime)
        traceback.print_exc(None, errlog)
        errlog.close()

#-------------------------------------------------------------------------------
class NNSplice:
    def __init__(self, min_donor, min_acc):
        self.min_donor = min_donor
        self.min_acc = min_acc
        self.re1 = re.compile('Hit \d+: position: (\d+) .. (\d+)')
        self.re2 = re.compile('Prediction: (\d\.\d+)')
        self.results = dict()    # 'Ref Donors': [(start, end, score), ...], 'Ref Acceptors': [...], ...
        self.results['Ref Donors'] = []
        self.results['Ref Acceptors'] = []
        self.results['Mut Donors'] = []
        self.results['Mut Acceptors'] = []

        # tmp filenames
        self.pid = os.getpid()
        prefix = 'ht_%s' % self.pid
        self.tmp = NamedTemporaryFile(prefix=prefix, dir=tmpdir)

    def predict(self, name, seq, offset):
        # input file
        input_file = '%s_nnsplice_%s_input.txt' % (self.tmp.name, name)
        fi = open(input_file, 'w')
        fi.write('> %s\n' % name)
        fi.write(seq)
        fi.close()

        # main cmd
        self.timeoutseconds = 60

        cmd = '%s/fa2Donorpred.linux -t %s -p %s'
        self.cmdline = cmd % (nnspliceDir, self.min_donor, input_file)
        self.runsplice('%s Donors' % name, offset)

        cmd = '%s/fa2Accpred.linux -t %s -p %s'
        self.cmdline = cmd % (nnspliceDir, self.min_acc, input_file)
        self.runsplice('%s Acceptors' % name, offset)
        
        os.remove(input_file)

    def runsplice(self, slotName, offset):
        # run
        flag = self.run()
        if flag:
            resSlot = self.results[slotName]
            tab = re.split('\n', self.stdout)
            try:
                for line in tab:
                    m = self.re1.match(line)
                    if m:
                        start = int(m.group(1)) + offset
                        end = int(m.group(2)) + offset
                    else:
                        m = self.re2.match(line)
                        if m:
                            score = m.group(1)
                            if len(resSlot) == 0 or start > resSlot[len(resSlot)-1][0]:
                                resSlot.append((start, end, score))
            except:
                pass

    def run(self):
        signal.signal(signal.SIGALRM, alarm_handler)
        signal.alarm(self.timeoutseconds)
        try:
            proc = subprocess.Popen(self.cmdline, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize =-1, shell=True)
            self.stdout, self.stderr = proc.communicate()
            signal.alarm(0)
            return True
        except HTException:
            return False

def alarm_handler(signum, frame):
    raise HTException

if (__name__ == "__main__"):
    main()

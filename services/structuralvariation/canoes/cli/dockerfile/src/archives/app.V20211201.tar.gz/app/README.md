# canoes
snakemake pipeline to launch CANOES (CNVs with an Arbitrary Number Of Exome Samples)

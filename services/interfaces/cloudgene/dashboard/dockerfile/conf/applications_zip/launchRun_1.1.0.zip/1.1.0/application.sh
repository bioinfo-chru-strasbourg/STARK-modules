#!/bin/bash

# INPUT
RUN=$1
CPU=$2
MEM=$3
QOS=$4
OPTIONS=$5

DEBUG=0
COMMAND=SLURM

# RUN

if [ "$RUN" == "" ]; then
    echo "#[ERROR] Need RUN parameter"
    exit 1
fi;
if [ "$RUN" != "" ] && [ ! -d /STARK/inputs/Input/runs/$RUN ]; then
    echo "#[ERROR] Run '$RUN' does NOT exists"
    exit 1
fi;

# CPU
if [ "$CPU" == "" ]; then
    echo "#[WARNING] NO CPU. default 1"
    CPU=1
fi;

# MEM
if [ "$MEM" == "" ]; then
    echo "#[WARNING] NO MEM. default 8"
    MEM=8
fi;

# QOS
if [ "$QOS" == "" ]; then
    echo "#[WARNING] NO QOS. default 'high'"
    QOS="high"
fi;




# Param
MD5="CloudGene"$RANDOM$RANDOM$RANDOM
ID="CloudGene-ID-$MD5-NAME-$RUN"
MD5_LOG="$LOG_FOLDER/$ID.log"
MD5_SLURM="$LOG_FOLDER/$ID.json"
MD5_SLURM_info="$LOG_FOLDER/$ID.info"
MD5_SLURM_output="$LOG_FOLDER/$ID.output"
MD5_SLURM_error="$LOG_FOLDER/$ID.err"

echo "#[INFO] RUN: $RUN"
echo "#[INFO] CPU: $CPU"
echo "#[INFO] MEM: $MEM"
echo "#[INFO] QOS: $QOS"
echo "#[INFO] OPT: $OPTIONS"
echo "#[INFO] JOB: $ID"

# SLURM
if [ "$COMMAND" == "SLURM" ]; then

	# SLURM config
	SLURM_USER=root
    SLURM_ACCOUNT=stark
    SLURM_CONFIG_FOLDER=/STARK/config/common/slurm
	SLURM_TOKEN=$(cat $SLURM_CONFIG_FOLDER/slurm)
	SLURM_OPENAPI_RELEASE=$(cat $SLURM_CONFIG_FOLDER/openapi_release)
	SLURM_REST_URL=$(cat $SLURM_CONFIG_FOLDER/rest_hostname) #"rest"

	# SLURM check response
	CMD_SLURM_CHECK="curl -s -H 'X-SLURM-USER-NAME:$SLURM_USER' -H 'X-SLURM-USER-TOKEN:$SLURM_TOKEN' http://$SLURM_REST_URL/slurm/$SLURM_OPENAPI_RELEASE/jobs"
	(($DEBUG)) && echo "CMD_SLURM_CHECK=$CMD_SLURM_CHECK"
	if eval $CMD_SLURM_CHECK 1>/dev/null 2>/dev/null; then
	#if eval $CMD_SLURM_CHECK; then
		(($DEBUG)) && echo "#[INFO] SLURM connexion pass"
	else
		(($DEBUG)) && echo "#[WARNING] SLURM connexion failed"
		echo "#[ERROR] SLURM connexion failed!!!"
		exit 1
	fi;
	
    # SLURM config
    SLURM_STARK_RUN_NAME="STARK RUN '$RUN' [ID:$MD5]"

    # STARK COMMAND
    STARK_RUN_EXTRA_PARAMS=$OPTIONS #"--release_infos"
    SLURM_STARK_RUN_CMD="docker run --entrypoint=bash --rm --cpus=${CPU} --memory=${MEM}g --name ${ID} ${DOCKER_STARK_MOUNT} ${DOCKER_STARK_IMAGE} -c 'STARK --runs=${RUN} --threads=${CPU} ${STARK_RUN_EXTRA_PARAMS} > ${MD5_SLURM_output}'"
    # STARK COMMAND FINISHED
    SLURM_STARK_RUN_INFO="docker run --rm --entrypoint=bash ${DOCKER_STARK_MOUNT} ${DOCKER_STARK_IMAGE} -c 'cat ${MD5_SLURM_output} > ${MD5_SLURM_info} && chmod 0775 ${MD5_SLURM_info}'"
    #SLURM_STARK_RUN_INFO="cat ${MD5_SLURM_output} > ${MD5_SLURM_info} && chmod 0775 ${MD5_SLURM_info}"
    # STARK COMMAND FINISHED with error
    SLURM_STARK_RUN_ERROR="docker run --rm --entrypoint=bash ${DOCKER_STARK_MOUNT} ${DOCKER_STARK_IMAGE} -c 'cat ${MD5_SLURM_output} > ${MD5_SLURM_error} && chmod 0775 ${MD5_SLURM_error}'"
    #SLURM_STARK_RUN_ERROR="cat ${MD5_SLURM_output} > ${MD5_SLURM_error} && chmod 0775 ${MD5_SLURM_error}"

    # create sbatch in json
    echo '{' > $MD5_SLURM
    echo '	"job": {' >> $MD5_SLURM
    echo '		"account": "'$SLURM_ACCOUNT'",' >> $MD5_SLURM
    echo '		"tasks": 1,' >> $MD5_SLURM
    echo '		"name": "'$SLURM_STARK_RUN_NAME'",' >> $MD5_SLURM
    echo '		"nodes": 1,' >> $MD5_SLURM
    echo '		"cpus_per_task": '$CPU',' >> $MD5_SLURM
    echo '		"memory_per_node": "'$MEM'G",' >> $MD5_SLURM
    echo '		"QOS": "'$QOS'",' >> $MD5_SLURM
    echo '		"current_working_directory": "/tmp/",' >> $MD5_SLURM
    echo '		"environment": {' >> $MD5_SLURM
    echo '			"PATH": "/bin:/usr/bin/:/usr/local/bin/",' >> $MD5_SLURM
    echo '			"LD_LIBRARY_PATH": "/lib/:/lib64/:/usr/local/lib"' >> $MD5_SLURM
    echo '		}' >> $MD5_SLURM
    echo '	},' >> $MD5_SLURM
    echo '	"script": "#!/bin/bash\nsrun '${SLURM_STARK_RUN_CMD}' && ('${SLURM_STARK_RUN_INFO}' && exit 0 || exit 1) || (('${SLURM_STARK_RUN_INFO}' || exit 1) && ('${SLURM_STARK_RUN_ERROR}' || exit 1) && exit 1) "' >> $MD5_SLURM
    #echo '	"script": "#!/bin/bash\nsrun '${SLURM_STARK_RUN_CMD}' && ('${SLURM_STARK_RUN_INFO}' && exit 0 || exit 1) || (('${SLURM_STARK_RUN_INFO}' || exit 1) && ('${SLURM_STARK_RUN_ERROR}' || exit 1) && exit 1) "' >> $MD5_SLURM
    #echo '	"script": "#!/bin/bash\nif srun '${SLURM_STARK_RUN_CMD}'; then ('${SLURM_STARK_RUN_INFO}' || exit 1); else ('${SLURM_STARK_RUN_INFO}' || exit 1) && ('${SLURM_STARK_RUN_ERROR}' || exit 1) && exit 1; fi; "' >> $MD5_SLURM
    echo '}' >> $MD5_SLURM
    (($DEBUG)) && cat $MD5_SLURM

    # Create command for SLURM
    CMD="curl -s -H 'X-SLURM-USER-NAME:$SLURM_USER' -H 'X-SLURM-USER-TOKEN:$SLURM_TOKEN' -H 'Content-Type: application/json' -X POST -d @$MD5_SLURM http://$SLURM_REST_URL/slurm/$SLURM_OPENAPI_RELEASE/job/submit"
    (($DEBUG)) && echo $CMD

    eval $CMD 1>> $MD5_LOG 2>> $MD5_LOG

    (($DEBUG)) && cat $MD5_LOG
    
    ERROR_CODE=$(grep '"error_code": ' $MD5_LOG | awk -F" " '{print $2}' | sed "s/,//gi")
    ERROR_MSG=$(grep '"error": "' $MD5_LOG | cut -d" " -f2-)

    if [ "$ERROR_CODE" != "" ]; then
        echo "#[ERROR] SLURM $ERROR_CODE: $ERROR_MSG "
        exit 1
    else
        while [ ! -f ${MD5_SLURM_info} ]; do
            sleep 10 # or less like 0.2
        done
        echo ""
        cat ${MD5_SLURM_info}
        if [ -e ${MD5_SLURM_error} ]; then
            exit 1;
        fi;
        
    fi;
    # "error_code": 2066,
    # "error": "Invalid qos specification"
fi;

# LUANCHER STARK API (deprecated)
if [ "$COMMAND" == "LAUNCHER" ]; then

    SERVICE=$2
    [ -z $SERVICE ] && SERVICE="stark-module-stark-submodule-stark-service-api:8000"
    echo "SERVICE=$SERVICE"
    echo curl -s -X POST -H 'Content-Type: application/json' -d '{"run":"'$1'"}' http://$SERVICE/analysis
    curl -s -X POST -H 'Content-Type: application/json' -d '{"run":"'$1'"}' http://$SERVICE/analysis

fi;
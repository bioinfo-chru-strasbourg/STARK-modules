# launchRun
Launch Run with STARK and SLURM

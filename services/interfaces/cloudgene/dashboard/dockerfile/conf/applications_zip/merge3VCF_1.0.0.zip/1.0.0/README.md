# merge3VCF
Merge 3 VCF Application for Cloudgene

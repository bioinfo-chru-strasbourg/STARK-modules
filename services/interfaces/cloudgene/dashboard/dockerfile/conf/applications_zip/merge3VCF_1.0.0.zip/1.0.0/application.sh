#!/bin/bash
echo $1 $2 $3
VCF1=$1
VCF2=$2
VCF3=$3
OUTPUT=$4
[ ! -e $VCF1.tbi ] && tabix $VCF1
[ ! -e $VCF2.tbi ] && tabix $VCF2
[ ! -e $VCF3.tbi ] && tabix $VCF3
bcftools merge $VCF1 $VCF2 $VCF3 --force-samples -O z1 > $OUTPUT/merged.vcf.gz
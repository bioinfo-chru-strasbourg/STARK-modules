#!/bin/bash
echo $1 $2
RUN=$1
SERVICE=$2
[ -z $SERVICE ] && SERVICE="stark-module-stark-submodule-stark-service-api:8000"
echo "SERVICE=$SERVICE"
echo curl -s -X POST -H 'Content-Type: application/json' -d '{"run":"'$1'"}' http://$SERVICE/analysis
curl -s -X POST -H 'Content-Type: application/json' -d '{"run":"'$1'"}' http://$SERVICE/analysis
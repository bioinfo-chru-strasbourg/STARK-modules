#!/bin/bash
echo $1
APP=$1
echo "APP=$APP"
cloudgene install $APP
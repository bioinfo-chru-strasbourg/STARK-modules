# installApp
Install an CloudGene Application with a TarBall (zip) file
